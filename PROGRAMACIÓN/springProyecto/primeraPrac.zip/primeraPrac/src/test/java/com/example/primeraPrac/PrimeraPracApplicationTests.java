package com.example.primeraPrac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeraPracApplicationTests {

	@Test
	void contextLoads() {
	}

}
